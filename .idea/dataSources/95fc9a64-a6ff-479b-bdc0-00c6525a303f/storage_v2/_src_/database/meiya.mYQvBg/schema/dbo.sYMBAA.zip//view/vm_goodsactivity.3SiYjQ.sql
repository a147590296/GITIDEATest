CREATE VIEW [dbo].[vm_goodsactivity] AS 
SELECT
g.id,
g.name,
g.price,
g.proPic,
g.sales,
hd.id hdid,
case when GETDATE() >= hd.begintiem AND GETDATE() <= hd.endtiem then 1 
else 0 end hdstate

FROM   dbo.pro_goods AS g 
LEFT OUTER JOIN dbo.pro_activitygoods AS ag ON ag.gid = g.id 
LEFT OUTER JOIN dbo.pro_activity AS hd ON ag.aid = hd.id
left join vm_goods gs on gs.id = g.id
where ((GETDATE() >= hd.begintiem AND GETDATE() <= hd.endtiem) or (GETDATE() <= hd.begintiem))
and (convert(char(10),ag.goodsactivitytime,120)=convert(char(10),GETDATE(),120) and hd.genre=4) or (GETDATE() >= hd.begintiem AND GETDATE() <= hd.endtiem and hd.genre<>4) and g.state <> -1
go

