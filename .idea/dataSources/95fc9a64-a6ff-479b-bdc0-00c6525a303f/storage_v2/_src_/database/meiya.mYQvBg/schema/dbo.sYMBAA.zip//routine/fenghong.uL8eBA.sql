CREATE PROCEDURE [dbo].[fenghong]
@uid INT = null
AS
BEGIN
  declare @totalFH DECIMAL(18,2)
	select @totalFH = sum(total-red_use)*0.05 from trade_order a where a.state = 5 and settle=0
	print '销售额：'+CAST(@totalFH as VARCHAR(20))
	DECLARE @totalFS INT
	select @totalFS = sum(share) from uc_user
	print '可分红份数：'+CAST(@totalFS as VARCHAR(20))

	DECLARE @MFJE DECIMAL(18,2)
	set @MFJE = @totalFH/@totalFS
	print '每份金额：'+CAST(@MFJE as VARCHAR(20))
	
	IF @uid is NULL
	BEGIN
		select id,userName,share,profit,gainprofit,
			case when e.vaild_money is null or e.vaild_money<=0 then 0 
			else 
					case when e.vaild_money< (case when @MFJE*share>profit*0.05 then profit*0.05 else @MFJE*share end) then e.vaild_money
					else 
						(case when @MFJE*share>profit*0.05 then profit*0.05 else @MFJE*share end) 
					end
			end '分红' from uc_user u
			LEFT JOIN acc_epurse e on u.id = e.uid and eType=2
			where share >0
	END
	ELSE
	BEGIN
		select id,userName,share,profit,gainprofit,
			case when e.vaild_money is null or e.vaild_money<=0 then 0 
			else 
					case when e.vaild_money< (case when @MFJE*share>profit*0.05 then profit*0.05 else @MFJE*share end) then e.vaild_money
					else 
						(case when @MFJE*share>profit*0.05 then profit*0.05 else @MFJE*share end) 
					end
			end '分红' from uc_user u
			LEFT JOIN acc_epurse e on u.id = e.uid and eType=2
			where share >0 and id = @uid
	END

END
go

